"""
Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
"""

__version__ = "2.0.7"
